export const ME_ROUTES = [
    // DASHBOARD: {
    //     PATH: 'dashboard',
    //     URL: '/dashboard'
    //   }
];