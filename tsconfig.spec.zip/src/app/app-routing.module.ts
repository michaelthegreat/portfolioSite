import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainLayoutComponent } from './app-layout/main-layout/main-layout.component';
import { APP_PATHS_ENUM } from './app.constants';
import { ContactPageComponent } from './contact/contact-page/contact-page.component';
import { HomePageComponent } from './home/home-page/home-page.component';
import { ShopPageComponent } from './shop/shop-page/shop-page.component';

const routes: Routes = [
  // {
  //   path: '**',
  //   component: MainLayoutComponent,
  //   // TODO: Add page not found component`
  //   // children: [
  //   //   {
  //   //     path: '',
  //   //     component: PageNotFoundComponent
  //   //   }
  //   // ]
  // },
  {
    path: APP_PATHS_ENUM.HOME,
    component: HomePageComponent
  },
  {
    path: APP_PATHS_ENUM.CONTACT,
    component: ContactPageComponent
  },
  {
    path: APP_PATHS_ENUM.SHOP,
    component: ShopPageComponent
  }

//   {
//     path: AppPathsEnum.PROFILE,
//     loadChildren: () => import('./modules/profile/profile.module').then((mod) => mod.ProfileModule),
//     canLoad: [AbacGuard],
//     canActivate: [MsalGuard],
// },
// {
//     path: AppPathsEnum.CONFIGURATIONS,
//     loadChildren: () =>
//         import('./modules/configurations/configurations.module').then((mod) => mod.ConfigurationsModule),
//     canLoad: [AbacGuard],
//     canActivate: [MsalGuard],
// },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
