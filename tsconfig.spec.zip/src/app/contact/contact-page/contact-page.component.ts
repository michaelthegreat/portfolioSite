import { Component, OnInit } from '@angular/core';
import { getContactForm } from '../contact.utils';

@Component({
  selector: 'app-contact-page',
  templateUrl: './contact-page.component.html',
  styleUrls: ['./contact-page.component.scss'],
})
export class ContactPageComponent implements OnInit {
  contactForm = getContactForm();
  resolvedCaptcha = false;
  constructor() {}

  ngOnInit(): void {}
  submit() {
    console.log('contact-page#submit', this.contactForm.getRawValue());
    if(this.resolvedCaptcha){
      console.log('captcha was resolved')
    }
    else {
      alert('please resolve the captcha')
    }
  }
  public resolved(captchaResponse: string) {
    console.log(`Resolved captcha with response: ${captchaResponse}`); // Write your logic here about once human verified what action you want to perform
    this.resolvedCaptcha = true;
  }
}
