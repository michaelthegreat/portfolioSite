import { NgModule } from '@angular/core';
import { ContactPageComponent } from './contact-page/contact-page.component';
import { UiMaterialModule } from '../ui-material/ui-material.module';
import { SharedModule } from '../shared/shared.module';
import { RecaptchaModule } from 'ng-recaptcha';

@NgModule({
  declarations: [ContactPageComponent],
  imports: [
    SharedModule,
    UiMaterialModule.forRoot({
      color: 'primary',
    }),
    RecaptchaModule,
  ],
  exports: [ContactPageComponent],
})
export class ContactModule {}
