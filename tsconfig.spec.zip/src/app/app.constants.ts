export enum APP_PATHS_ENUM {
    ROOT = '/',
    HOME = '',
    SHOP = 'shop',
    CONTACT = 'contact'
}