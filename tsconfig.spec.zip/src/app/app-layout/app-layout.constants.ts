import { APP_PATHS_ENUM } from "../app.constants";

export const ME_NAV_LINKS = [
    {
        path: APP_PATHS_ENUM.HOME,
        label: 'Home',
        data: {},
    },
    {
        path: APP_PATHS_ENUM.SHOP,
        label: 'Shop',
        data: {},
    },
    {
        path: APP_PATHS_ENUM.CONTACT,
        label: 'Contact',
        data: {},
    },
];

